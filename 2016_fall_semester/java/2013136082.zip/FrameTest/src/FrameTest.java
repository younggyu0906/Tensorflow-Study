import java.awt.*;
import javax.swing.*;

class MyFrame extends JFrame {
	public MyFrame() {
		setSize(300,200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("My Frame");
		
		JPanel panel = new JPanel();
		JPanel panelA = new JPanel();
		JPanel panelB = new JPanel();
		
		JLabel label = new JLabel("Welcome to Java Pizza. Select Pizza");
		panelA.add(label);
		
		JButton b1 = new JButton("Combo");
		JButton b2 = new JButton("Potato");
		JButton b3 = new JButton("Bulgogi");
		
		panelB.add(b1);
		panelB.add(b2);
		panelB.add(b3);
		
		panel.add(panelA);
		panel.add(panelB);
		
		panel.setBackground(Color.BLUE);
		panelA.setBackground(Color.RED);
		panelB.setBackground(new Color(50,50,50));
		
		add(panel);
		setVisible(true);
	}
}
public class FrameTest {
	public static void main(String[] args) {
		MyFrame f = new MyFrame();
	}
}