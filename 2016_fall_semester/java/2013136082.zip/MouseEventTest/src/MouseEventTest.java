// MouseListener interace �� MouseMotionListener interface��
// implements �ϴ� ��� MouseListener�� ����� �޼ҵ� 5����
// MouseMotionListener�� ����� 2���� �޼ҵ带 ��� �����ؾ� �Ѵ�.
import javax.swing.*;
import java.awt.event.*;

class MyFrame extends JFrame {
	JPanel panel;
	
	public MyFrame() {
		setTitle("MouseEvent");
		setSize(300,200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.addMouseListener(new MyMouseListener());
		panel.addMouseMotionListener(new MyMotionListener());
		add(panel);
		setVisible(true);
	}
	private class MyMouseListener extends MouseAdapter {
		public void mouseClicked(MouseEvent e) {
			display("mouse clicked (# of clicks : " + e.getClickCount() + ")", e);
		}
	}
	private class MyMotionListener extends MouseMotionAdapter {
		public void mouseDragged(MouseEvent e) {
			display("mouse dragged", e);
		}
	}
	public void display(String s, MouseEvent e) {
		System.out.println(s + " x = " + e.getX() + " y = " + e.getY());
		System.out.println(e.getButton());
	}
}

public class MouseEventTest {

	public static void main(String[] args) {
		MyFrame mouse = new MyFrame();

	}

}
