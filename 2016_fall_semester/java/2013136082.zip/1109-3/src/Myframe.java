import java.awt.*;
import javax.swing.*;
class MyPanel extends JPanel{
	//JComponent Ŭ������ paintComponent ������
	public void paintComponent(Graphics g){ //graphics ��ü�� �Ű������� �޴´�
		super.paintComponent(g); //�ݵ�� �߰�
		g.setColor(Color.orange);
		g.drawString("Hello JAVA PROgrammers! ",10,10);
		g.setColor(Color.black);
		g.drawLine(0,10,1100,10);
		g.fillRect(10,30,500,500);//��ǥ,����,����
		g.setColor(Color.red);
		g.fillRect(50,50,500,500);
		for(int i=0 ; i<10 ; i++){
			g.setColor(Color.white);
			g.drawRect(50+10*i,50+10*i,500,500);
			g.setColor(Color.black);
			g.fillOval(50+20*i,50+20*i,500,500);
		}
		g.setColor(new Color(155,155,200));
		g.drawRoundRect(0,0,50,50,30,30);
		
	}
}

public class Myframe extends JFrame{

	public Myframe(){
		setTitle("My frame");
		setSize(300,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		MyPanel p = new MyPanel();
		add(p);
		setVisible(true);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Myframe f = new Myframe();
	}

}
