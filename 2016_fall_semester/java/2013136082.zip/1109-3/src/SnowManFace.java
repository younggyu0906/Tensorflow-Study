import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class MyPanel6 extends JPanel {
	JButton button;
	Color = new color (0,0,0);
	public MyPanel6(){
		setLayout(new BorderLayout());
		button = new JButton("���� ����");
		button.addActionListener(this);
		add(button , BorderLayout.SOUTH);
	}
	public void paintComponent(Graphics g){ //�ݵ�� �߰�, �̸��� ���ƾ� ��
		super.paintComponent(g);
		g.setColor(Color.red);
		g.fillOval(20, 40, 200, 200);
		g.setColor(new Color(140,255,52));
		g.drawArc(60, 80, 50, 50, 170, 360);
		g.drawArc(150, 80, 50, 50, 90, 360);
		g.drawArc(70, 130, 100, 70, 0, 360);
		g.drawLine(80, 80, 30, 30);
	}
	
	private class MyListner implements ActionListener{
		public void actionPerformed(ActionEvent e){
			color =new Color((int)(Math.random()*255),(int)(Math.random()*255),(int)(Math.random()*255));
			repaint();
		}
	}

}


public class SnowManFace extends JFrame {
	public SnowManFace(){
		setSize(280,300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Snow Man Face");
		MyPanel5 p = new MyPanel5();
		add(p);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SnowManFace s = new SnowManFace();
	}

}
