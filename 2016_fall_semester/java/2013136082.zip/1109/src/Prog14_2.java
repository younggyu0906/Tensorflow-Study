import java.awt.*;

import javax.swing.*;

class MyFrame7 extends JFrame{
	
	public  MyFrame7(){
		setTitle("Interest Calculator");
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setSize(300,200);
			setLayout(new GridLayout(4,1));
			JPanel p1,p2,p3,p4;
			
			JPanel p = new JPanel();
			p.setLayout(null);
			//panel.setLayout(new FlowLayout(FlowLayout.LEADING, 10,20));
			//JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER,10,20));
			//FlowLayout.LEADING,Center,TRAILING
			p1 = new JPanel();
			p2 = new JPanel();
			p3 = new JPanel();
			p4 = new JPanel();
			
			JLabel l1 = new JLabel("Enter Principal : ");
			JTextField f1 = new JTextField(10);
			JLabel l2 = new JLabel("Enter Interest Rate: ");
			JTextField f2 = new JTextField(10);
			JLabel l3 = new JLabel("Calcultate : ");
			JTextField f3 = new JTextField(20);
			p1.add(l1);
			p1.add(f1);
			p2.add(l2);
			p2.add(f2);
			p3.add(l3);
			p3.add(f3);
			add(p1); add(p2); add(p3); add(p4);
			//panel.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
			pack();
			setVisible(true);
	}
}

public class Prog14_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyFrame7 f = new MyFrame7();
	}

}
