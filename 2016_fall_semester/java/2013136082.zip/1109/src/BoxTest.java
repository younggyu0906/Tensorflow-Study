import java.awt.*;

import javax.swing.*;

class MyFrame5 extends JFrame{
	public  MyFrame5(){
			setTitle("BoxLayout Test");
			setSize(300,500);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			JPanel panel = new JPanel();
			
			panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS)); //X_AXIS , Y_AXIS �����̳� �����̳� ����
			//JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER,10,20));
			//FlowLayout.LEADING,Center,TRAILING
			makeButton(panel,"Button1");
			makeButton(panel,"Button2");
			makeButton(panel,"Button3");
			makeButton(panel,"B4");
			makeButton(panel,"Long Button5");
			
			add(panel);
			//panel.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
			pack(); //ũ������
			setVisible(true);
	}


	private void makeButton(JPanel p, String text) {
		JButton button = new JButton(text);
		button.setAlignmentX(Component.RIGHT_ALIGNMENT); //�߾����� 
		button.setMaximumSize(new Dimension(200,100)); //��ư�� �ִ� ũ�� ����
		p.add(button);
		
	}
}

public class BoxTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyFrame5 f = new MyFrame5();

	}

}
