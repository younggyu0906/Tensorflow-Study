import java.awt.*;
import javax.swing.*;

class MyFrame3 extends JFrame{
		public  MyFrame3(){
				setTitle("GridLayout Test");
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				setLayout(new GridLayout(3,1));
				
				JPanel panel = new JPanel();
				//panel.setLayout(new FlowLayout(FlowLayout.LEADING, 10,20));
				//JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER,10,20));
				//FlowLayout.LEADING,Center,TRAILING
				add(new JButton("Button1"));
				add(new JButton("Button2")); //Panel.�� �ȵ�
				add(new JButton("Button3"));
				add(new JButton("B4"));
				add(new JButton("Long Button5"));

				//panel.applyComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
				pack(); //ũ������
				setVisible(true);
		}
}



public class GridTest {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyFrame3 f = new MyFrame3();
	}

}
