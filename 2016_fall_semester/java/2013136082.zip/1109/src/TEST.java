import java.awt.*;
import javax.swing.*;
class MyFrame10 extends JFrame{
	public MyFrame10(){
	setTitle("Interest Calculater");
	setSize(400,500);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setLayout(new GridLayout(1,5,0,5));
	JPanel p1,p2,p3,p4;
	p1=new JPanel();
	p2=new JPanel();
	p3=new JPanel();
	p4=new JPanel();
	
	JLabel l1 = new JLabel("������ �Է��Ͻÿ�.");
	JTextField f1 = new JTextField(10);
	JLabel l2 = new JLabel("���ڸ� �Է��ϼ���.");
	JTextField f2 = new JTextField(10);
	JButton b = new JButton("��갪");
	JTextField f3 = new JTextField(20);
	p1.add(l1);
	p1.add(f1);
	p1.add(l2);
	p1.add(f2);
	p1.add(b);
	p1.add(f3);
	add(p1);add(p2);
	add(p3);add(p4);	
	pack();
	setVisible(true);
	
}
}
public class TEST {

	public static void main(String[] args) {
		MyFrame10 f = new MyFrame10();

	}

}
