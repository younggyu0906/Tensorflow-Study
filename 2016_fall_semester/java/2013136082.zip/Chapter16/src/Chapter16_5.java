//import javax.swing.*;
//import java.awt.event.*;
//
//class MyFrame extends JFrame {
//	JPanel panel = new JPanel();
//	public MyFrame() {
//		super();
//		setTitle("Key Event Example");
//		setSize(300, 200);
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		
//		JTextField tf = new JTextField(20);
//		tf.addKeyListener(new MyKeyListener());
//		
//		tf.requestFocus();		//event�� �޵��� �Ѵ�
//		panel.add(tf);
//		add(panel);
//		setVisible(true);
//	}
//	private class MyKeyListener implements KeyListener {
//		public void keyPressed(KeyEvent e) {
//			display(e, "KeyPressed");
//		}
//		public void keyReleased(KeyEvent e) {
//			display(e, "KeyReleased");
//		}
//		public void keyTyped(KeyEvent e) {	//unicode �� ���
//			display(e, "KeyTyped");
//		}
//	}
//	private void display(KeyEvent e, String s) {
//		char ch = e.getKeyChar();
//		int keyCode = e.getKeyCode();		//keyTyped ���� 0
//		String modifiers = e.isAltDown() + " " + e.isControlDown() + " " +
//		e.isShiftDown();
//		System.out.println(s + " " + ch + " " + keyCode + " " + modifiers);
//	}
//}
//public class Chapter16_5 {
//	public static void main(String[] args) {
//		new MyFrame();
//	}
//}