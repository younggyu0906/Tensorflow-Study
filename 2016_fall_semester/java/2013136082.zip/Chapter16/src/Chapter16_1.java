//import java.awt.event.ActionEvent;
//
//import javax.swing.*;
//import java.awt.event.*;
//
//class MyFrame extends JFrame {
//	private JButton button;
//	private JLabel label;
//	private int count = 0;
//	
//	public MyFrame() {
//		setSize(300, 200);
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		setTitle("Event Example");
//		
//		JPanel panel = new JPanel();
//		button = new JButton("Press Button");
//		label = new JLabel("Button is not pressed yet");
//		button.addActionListener(new MyListener());
//		panel.add(button);
//		panel.add(label);
//		add(panel);
//		setVisible(true);
//	}
//	private class MyListener implements ActionListener {
//		public void actionPerformed(ActionEvent e) {
//			if(e.getSource() == button)		//event �߻� ��ü�� �̸� ����
//				label.setText("Button is pressed : " +  ++count);
//		}
//	}
//}
//public class Chapter16_1 {
//	public static void main(String[] args) {
//		MyFrame f = new MyFrame();
//	}
//}