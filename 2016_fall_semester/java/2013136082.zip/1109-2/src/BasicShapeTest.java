import java.awt.*;
import javax.swing.*;

class MyPanel extends JPanel{
		public void paintComponent(Graphics g){ //�ݵ�� �߰�, �̸��� ���ƾ� ��
			super.paintComponent(g);
			g.setColor(Color.green);
			g.drawRect(10, 30, 100, 100);
			g.fillRect(150, 50, 50, 50);
			
			g.draw3DRect(250, 50, 50, 50, true);
			g.fill3DRect(350, 50, 50, 50, true);
		}
	
}


public class MyFrame11 extends JFrame{

	public MyFrame11(){
			super("Basic Shape Drawing");
			setSize(700,300);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			MyPanel p = new MyPanel();
			add(p);
			setVisible(true);
	}
}
public class BasicShapeTest{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyFrame11 f = new MyFrame11();
	}
}

