import java.awt.*;

import javax.swing.*;

class MyPanel extends JPanel{
		public void paintComponent(Graphics g){ //�ݵ�� �߰�, �̸��� ���ƾ� ��
			super.paintComponent(g);
			g.setColor(Color.green);
			g.drawString("Hello, Java Programmers!!!", 10,10);
			g.drawLine(10, 20, 110, 120);
			g.drawRect(10, 30, 100, 100);
		}
	
}


public class MyFrame extends JFrame{

	public MyFrame(){
			setTitle("My Frame");
			setSize(300,700);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			MyPanel p = new MyPanel();
			add(p);
			setVisible(true);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyFrame f = new MyFrame();
	}

}
