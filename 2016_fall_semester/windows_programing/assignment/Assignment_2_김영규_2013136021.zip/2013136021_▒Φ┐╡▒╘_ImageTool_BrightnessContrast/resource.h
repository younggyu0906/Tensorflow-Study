//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ImageTool.rc
//
#define IDD_FILE_NEW                    9
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             101
#define IDR_MAINFRAME                   128
#define IDR_ImageToolTYPE               129
#define IDD_BRIGHTNESS                  130
#define IDD_BRIGHTNESS_CONTRAST         130
#define IDD_HISTOGRAM                   131
#define IDC_WIDTH                       1001
#define IDC_HEIGHT                      1002
#define IDC_IMAGETYPE                   1003
#define IDC_BRIGHTNESS_SLIDER           1004
#define IDC_BRIGHTNESS_EDIT             1005
#define IDC_CONTRAST_SLIDER             1008
#define IDC_CONTRAST_EDIT               1009
#define IDC_EDIT2                       1010
#define ID_WINDOW_DUPLICATE             32771
#define ID_VIEW_ZOOM1                   32772
#define ID_VIEW_ZOOM2                   32773
#define ID_VIEW_ZOOM3                   32774
#define ID_VIEW_ZOOM4                   32775
#define ID_IMAGE_BRIGHTNESS             32776
#define ID_IMAGE_BRIGHTNESS_CONTRAST    32777
#define ID_32778                        32778
#define ID_HISTOGRAM                    32779
#define ID_32780                        32780
#define ID_HISTO_EQUALIZATION           32781
#define ID_32782                        32782
#define ID_32783                        32783
#define ID_32784                        32784

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
