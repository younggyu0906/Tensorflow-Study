import java.util.*;

public class Binomial { 
  public static void main(String args[]) {
    Scanner input = new Scanner(System.in);
    int n, k;
    long startTime=0, endTime=0, result, result2; 
    System.out.print("enter the n : "); 
    n = input.nextInt();
    System.out.print("enter the k : "); 
    k = input.nextInt();

    startTime = System.nanoTime(); 
    result = binomial1(n,k); // binomial1 
    endTime = System.nanoTime();
    System.out.println("\n[binomial 1]\nElapsed Time : " + (endTime - startTime) + " nanotime\tresult : " + result);    

    startTime = System.nanoTime();
    result = binomial2(n,k); // binomial2 
    endTime = System.nanoTime();
    System.out.println("\n[binomial 2]\nElapsed Time : " + (endTime - startTime) + " nanotime\tresult : " + result);
  }
    
  public static int minimum(int i, int k) { 
    return (i >= k ? k: i);
  }
  
  public static int binomial1(int n, int k) {
    int i, j;
    int[][] B = new int[n+1][k+1];
    
    //...
    
    return B[n][k];
  }
  
  public static int binomial2(int n, int k) {
    int i, j;
  	if ( k > n-k ) // k  n-k  
      k = n-k;
    int[] B = new int[k+1];
    
		//...
		
    return B[k];
  }
}