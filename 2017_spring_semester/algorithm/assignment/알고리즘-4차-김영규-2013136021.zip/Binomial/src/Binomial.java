// 2013136021 �迵��
// ���װ�� �˰�����
import java.util.*;

public class Binomial { 
  public static void main(String args[]) {
    Scanner input = new Scanner(System.in);
    int n, k;
    long startTime=0, endTime=0, result, result2; 
    System.out.print("enter the n : "); 
    n = input.nextInt();
    System.out.print("enter the k : "); 
    k = input.nextInt();

    startTime = System.nanoTime(); 
    result = binomial1(n,k); // binomial1 
    endTime = System.nanoTime();
    System.out.println("\n[binomial 1]\nElapsed Time : " + (endTime - startTime) + " nanotime\tresult : " + result);    

    startTime = System.nanoTime();
    result = binomial2(n,k); // binomial2 
    endTime = System.nanoTime();
    System.out.println("\n[binomial 2]\nElapsed Time : " + (endTime - startTime) + " nanotime\tresult : " + result);
  }
    
  public static int minimum(int i, int k) { 
    return (i >= k ? k: i);
  }
  
  public static int binomial1(int n, int k) {
    int i, j;
    int[][] B = new int[n+1][k+1];
    
    for(i = 0; i < n + 1; i++)
    	for(j = 0; j <= minimum(i, k); j++) {
    		if(j == 0 || j == 1)
    			B[i][j] = 1;
    		else
    			B[i][j] = B[i - 1][j - 1] + B[i - 1][j];
    	}
    return B[n][k];
  }
  
  public static int binomial2(int n, int k) {
    int i, j;
  	if ( k > n-k ) // k  n-k  
      k = n-k;
    int[] B = new int[k+1];
    
    B[0] = 1;
    
    for (i = 0; i <= n; i++) {
    	for(j = minimum(i, k); j > 0; j--) {
    		B[j] = B[j - 1] + B[j];
    	}
    }
		//...
		
    return B[k];
  }
}